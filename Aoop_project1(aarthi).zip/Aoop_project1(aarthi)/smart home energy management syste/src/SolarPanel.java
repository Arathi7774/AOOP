public class SolarPanel {
    public double getSolarEnergy() {
        return 5.0;  // Assume 5 kWh produced by solar panels
    }
}
