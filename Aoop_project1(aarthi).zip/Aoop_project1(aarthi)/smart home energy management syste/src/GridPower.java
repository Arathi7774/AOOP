public class GridPower {
    public double getGridEnergy() {
        return 15.0;  // Assume 15 kWh provided by grid power
    }
}
