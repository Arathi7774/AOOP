public class WindTurbine {
    public double getWindEnergy() {
        return 10.0;  // Assume 10 kWh produced by wind turbine
    }
}
