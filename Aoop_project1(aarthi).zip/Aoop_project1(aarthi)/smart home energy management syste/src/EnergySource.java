public interface EnergySource {
    double getEnergyOutput();  // Returns energy in kWh
}
